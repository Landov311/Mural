import React from 'react';
import Mural from './components/Mural';

const App = () => <Mural />;

export default App;
